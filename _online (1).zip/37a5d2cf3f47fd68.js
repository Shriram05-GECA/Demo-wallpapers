(self["webpackChunk_canva_web"] = self["webpackChunk_canva_web"] || []).push([[310],{

/***/ 29862:
function(_, __, __webpack_require__) {__webpack_require__.n_x = __webpack_require__.n;const __web_req__ = __webpack_require__;__web_req__(813110);self._fe4d99ebe0d2d259646a80d250150d47 = self._fe4d99ebe0d2d259646a80d250150d47 || {};(function(__c) {
}).call(self, self._fe4d99ebe0d2d259646a80d250150d47);}

}])